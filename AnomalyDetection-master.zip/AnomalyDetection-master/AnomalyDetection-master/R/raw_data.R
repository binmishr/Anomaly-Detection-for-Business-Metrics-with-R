#' @name raw_data
#' @title raw_data
#' @description A data frame containing a time series with headings timestamp and count.
#' @docType data
#' @usage data(raw_data)
NULL